<?php

defined('_JEXEC') or die('Restricted access');

use Joomla\CMS\MVC\Controller\BaseController;

class JuridicoController extends JControllerLegacy
{

    protected $default_view = 'default';


}